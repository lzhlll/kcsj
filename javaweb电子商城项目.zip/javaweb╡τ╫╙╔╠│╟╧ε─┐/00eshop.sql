/*
Navicat MySQL Data Transfer

Source Server         : my
Source Server Version : 50647
Source Host           : localhost:3306
Source Database       : eshop

Target Server Type    : MYSQL
Target Server Version : 50647
File Encoding         : 65001

Date: 2021-02-05 12:44:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_address
-- ----------------------------
DROP TABLE IF EXISTS `t_address`;
CREATE TABLE `t_address` (
  `addr_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `addr_province` varchar(20) NOT NULL,
  `addr_city` varchar(20) NOT NULL,
  `addr_area` varchar(50) NOT NULL,
  `addr_content` varchar(100) NOT NULL,
  `addr_receiver` varchar(20) NOT NULL,
  `addr_tel` varchar(30) NOT NULL,
  `addr_isdefault` tinyint(4) NOT NULL,
  PRIMARY KEY (`addr_id`),
  KEY `addr_userid` (`user_id`),
  CONSTRAINT `addr_userid` FOREIGN KEY (`user_id`) REFERENCES `t_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_address
-- ----------------------------
INSERT INTO `t_address` VALUES ('1', '1', '辽宁', '大连', '甘井子区', '软件园路8号117', '张三', '13345678902', '0');
INSERT INTO `t_address` VALUES ('2', '1', '辽宁', '大连', '甘井子区', '软件园路1号220', '李四', '13312345678', '0');
INSERT INTO `t_address` VALUES ('3', '1', '辽宁1', '大连2', '甘井子区3', '软件园路8号1154', '张三5', '133123456786', '1');
INSERT INTO `t_address` VALUES ('7', '1', '北京1', '北京2', '朝阳3', '123街道4', '王五5', '13345678906', '0');
INSERT INTO `t_address` VALUES ('10', '1', '北京', '北京', '10', '北京', '王五', '13345678901', '0');
INSERT INTO `t_address` VALUES ('11', '1', '北京555', '北京2', '11', '北京2', '王五5', '133456789016', '0');
INSERT INTO `t_address` VALUES ('16', '5', '吉林1222', '长春2', '16', '长春2', '赵六54444', '15512345676', '0');
INSERT INTO `t_address` VALUES ('18', '5', '吉林', '长春', '18', '长春', '赵六12345', '15512345678', '0');
INSERT INTO `t_address` VALUES ('39', '4', '2', '2', '2', '2', '2', '3', '1');
INSERT INTO `t_address` VALUES ('42', '1', '11', '1', '0', '1', '东软', '12387699802', '0');
INSERT INTO `t_address` VALUES ('43', '5', '之昌', '444', '43', '444', '555', '555', '1');
INSERT INTO `t_address` VALUES ('44', '5', '辽宁省', '大连市', '44', '大连市', '张小姐', '2222', '0');
INSERT INTO `t_address` VALUES ('62', '5', '2', '2', '0', '2', '2', '2', '0');
INSERT INTO `t_address` VALUES ('67', '5', '1', '1', '0', '1', '1', '1', '0');
INSERT INTO `t_address` VALUES ('68', '5', '2', '2', '0', '2', '2', '2', '0');
INSERT INTO `t_address` VALUES ('70', '5', '江', '西', '0', '西', '222', '333', '0');
INSERT INTO `t_address` VALUES ('72', '5', '222', '222', '222', '222', '222', '222', '0');
INSERT INTO `t_address` VALUES ('73', '5', '5555', '5555', '555', '5555', '555', '55555', '0');
INSERT INTO `t_address` VALUES ('74', '15', '222', '222', '222', '222', '22', '222', '0');
INSERT INTO `t_address` VALUES ('80', '7', '11', '11', '11', '11', '11', '11', '0');
INSERT INTO `t_address` VALUES ('81', '7', '66', '66', '66', '66', '66', '66', '0');
INSERT INTO `t_address` VALUES ('82', '7', '4', '4', '4', '4', '4', '4', '0');
INSERT INTO `t_address` VALUES ('83', '7', 'e', 'e', 'e', 'e', 'e', 'e', '0');
INSERT INTO `t_address` VALUES ('84', '7', 'f', 'f', 'f', 'f', 'f', 'f', '0');
INSERT INTO `t_address` VALUES ('85', '7', 'a', 'a', 'a', 'a', 'a', 'a', '0');
INSERT INTO `t_address` VALUES ('86', '7', 'b', 'b', 'b', 'b', 'b', 'b', '0');
INSERT INTO `t_address` VALUES ('94', '8', '1', '1', '1', '1', '1', '1', '0');

-- ----------------------------
-- Table structure for t_category
-- ----------------------------
DROP TABLE IF EXISTS `t_category`;
CREATE TABLE `t_category` (
  `cate_id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(100) NOT NULL,
  `cate_pic` varchar(50) DEFAULT NULL,
  `parentid` int(11) DEFAULT NULL,
  `cate_desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`cate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_category
-- ----------------------------
INSERT INTO `t_category` VALUES ('1', '女装', '/images/cate/1.png', '16', null);
INSERT INTO `t_category` VALUES ('2', '男装', '/images/cate/2.png', '16', null);
INSERT INTO `t_category` VALUES ('3', '女士内衣', '/images/cate/3.png', '16', null);
INSERT INTO `t_category` VALUES ('4', '男士内衣', '/images/cate/4.png', '16', null);
INSERT INTO `t_category` VALUES ('5', '女鞋', '/images/cate/5.png', '17', null);
INSERT INTO `t_category` VALUES ('6', '男鞋', '/images/cate/6.png', '17', null);
INSERT INTO `t_category` VALUES ('7', '孕妇装', '/images/cate/7.png', '16', null);
INSERT INTO `t_category` VALUES ('8', '儿童装', '/images/cate/8.png', '16', null);
INSERT INTO `t_category` VALUES ('9', '婴幼儿装', '/images/cate/9.png', '16', null);
INSERT INTO `t_category` VALUES ('10', '配饰', '/images/cate/10.png', '16', null);
INSERT INTO `t_category` VALUES ('11', '箱包', '/images/cate/11.png', '17', null);
INSERT INTO `t_category` VALUES ('13', '食品', '/images/cate/1454665448253.jpg', null, '来来来，吃吃吃，买买买！');
INSERT INTO `t_category` VALUES ('15', '坚果', '/images/cate/1454722861160.jpg', '13', '');
INSERT INTO `t_category` VALUES ('16', '服装', '/images/cate/1.png', null, '穿的美美的，找回自信的你！');
INSERT INTO `t_category` VALUES ('17', '箱包靴鞋', '/images/cate/1.png', null, '有我陪伴，走遍天下。');
INSERT INTO `t_category` VALUES ('18', '甜点', '/images/cate/10.png', '13', '');
INSERT INTO `t_category` VALUES ('19', '海味', '/images/cate/10.png', '13', '');
INSERT INTO `t_category` VALUES ('20', '零食', '/images/cate/10.png', '13', null);
INSERT INTO `t_category` VALUES ('21', '电子类', '/images/cate/10.png', null, '电子产品');
INSERT INTO `t_category` VALUES ('22', '电脑', '/images/cate/1.png', '21', '各类电脑，应有尽有');

-- ----------------------------
-- Table structure for t_goods
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods` (
  `goods_id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_id` int(11) NOT NULL,
  `goods_name` varchar(50) NOT NULL,
  `goods_disc` text NOT NULL,
  `goods_price` float NOT NULL,
  `goods_discount` float DEFAULT NULL,
  `goods_stock` int(11) NOT NULL,
  `goods_origin` varchar(50) DEFAULT NULL,
  `goods_material` varchar(200) DEFAULT NULL,
  `goods_postalfee` float DEFAULT NULL,
  `goods_date` date DEFAULT NULL,
  `goods_sales` int(11) DEFAULT NULL,
  `goods_pic` varchar(50) DEFAULT NULL,
  `istoday` tinyint(1) DEFAULT '0' COMMENT '是否为今日推荐商品，1：是  0：否',
  PRIMARY KEY (`goods_id`),
  KEY `cate_id` (`cate_id`),
  CONSTRAINT `cate_id` FOREIGN KEY (`cate_id`) REFERENCES `t_category` (`cate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES ('1', '1', '女装 军旅式短茄克1', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '233', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-01', '30', '/images/goods/tj_1.jpg', '1');
INSERT INTO `t_goods` VALUES ('2', '1', '女装 军旅式短茄克2', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '243', '0', '上海', '棉56% 聚酯纤维30%', '10', '2016-01-29', '100', '/images/goods/1_2.png', '1');
INSERT INTO `t_goods` VALUES ('3', '1', '女装 军旅式短茄克3', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '32', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '80', '/images/goods/tj_3.png', '1');
INSERT INTO `t_goods` VALUES ('4', '1', '女装 军旅式短茄克4', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '235', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '2', '/images/goods/1_1.jpg', '1');
INSERT INTO `t_goods` VALUES ('5', '5', '女装 军旅式短茄克5', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '233', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/tj_5.png', '1');
INSERT INTO `t_goods` VALUES ('6', '1', '女装 军旅式短茄克6', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '122', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_3.png', '1');
INSERT INTO `t_goods` VALUES ('7', '1', '女装 军旅式短茄克7', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '134', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_1.jpg', '1');
INSERT INTO `t_goods` VALUES ('8', '1', '女装 军旅式短茄克8', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '134', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_2.png', '1');
INSERT INTO `t_goods` VALUES ('9', '1', '女装 军旅式短茄克9', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_3.png', '1');
INSERT INTO `t_goods` VALUES ('10', '1', '女装 军旅式短茄克10', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_3.png', '1');
INSERT INTO `t_goods` VALUES ('11', '1', '女装 军旅式短茄克11', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_1.jpg', '1');
INSERT INTO `t_goods` VALUES ('12', '1', '女装 军旅式短茄克12', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_1.jpg', '1');
INSERT INTO `t_goods` VALUES ('13', '1', '女装 军旅式短茄克13', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '200', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_1.jpg', '1');
INSERT INTO `t_goods` VALUES ('14', '1', '女装 军旅式短茄克14', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '199', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_2.png', '1');
INSERT INTO `t_goods` VALUES ('15', '1', '女装 军旅式短茄克15', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '222', '133', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('16', '1', '女装 军旅式短茄克16', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '355', '211', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('17', '1', '女装 军旅式短茄克17', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '123', '23', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-30', '0', '/images/goods/1_3.png', '0');
INSERT INTO `t_goods` VALUES ('18', '6', '女装 军旅式短茄克18', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '35', '17', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/5.png', '0');
INSERT INTO `t_goods` VALUES ('19', '6', '女装 军旅式短茄克19', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '68', '23', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/6.png', '0');
INSERT INTO `t_goods` VALUES ('20', '5', '女装 军旅式短茄克20', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/5.png', '0');
INSERT INTO `t_goods` VALUES ('21', '5', '女装 军旅式短茄克21', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/6.png', '0');
INSERT INTO `t_goods` VALUES ('22', '11', '男装 军旅式短茄克22', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/11.png', '0');
INSERT INTO `t_goods` VALUES ('23', '2', '男装 军旅式短茄克23', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '233', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('24', '2', '男装 军旅式短茄克24', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('25', '2', '男装 军旅式短茄克25', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('26', '2', '男装 军旅式短茄克26', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_2.png', '0');
INSERT INTO `t_goods` VALUES ('27', '2', '男装 军旅式短茄克27', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_2.png', '0');
INSERT INTO `t_goods` VALUES ('28', '2', '男装 军旅式短茄克28', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_3.png', '0');
INSERT INTO `t_goods` VALUES ('29', '2', '男装 军旅式短茄克29', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_3.png', '0');
INSERT INTO `t_goods` VALUES ('30', '2', '男装 军旅式短茄克30', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_3.png', '0');
INSERT INTO `t_goods` VALUES ('31', '2', '男装 军旅式短茄克31', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_2.png', '0');
INSERT INTO `t_goods` VALUES ('32', '2', '男装 军旅式短茄克32', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('33', '2', '男装 军旅式短茄克33', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('34', '2', '男装 军旅式短茄克34', '施有强水洗加工的军旅式外套。富有张力的面料，洋溢着十足的军旅气息。带盖口袋的金属圆形纽扣、兜帽口的锯齿形压线，彰显经典的军旅外套细节。大兜帽的样式，能适度修饰脸型。短款的设计，可与宽腿裤等宽松的下装搭配打造具有平衡感的造型。', '399', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '0', '/images/goods/1_2.png', '0');
INSERT INTO `t_goods` VALUES ('35', '15', '榛子', '美味可口', '350', '177', '0', '上海', '棉56% 聚酯纤维30%', '12', '2016-01-28', '1000', '/images/goods/tj_2.jpg', '1');
INSERT INTO `t_goods` VALUES ('36', '1', '女士内衣 新型收拢运动内衣', '纯棉超聚拢运动内衣，轻便贴身，显曲线，吸汗，穿着舒适', '123', '100', '456', '北京', '纯棉', '12', '2016-01-23', '0', '/images/goods/1_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('42', '19', '开口松子', '测试', '333', '222', '1557', '测试', '测试', '11', '2016-02-12', '40', '/images/goods/tj_4.png', '1');
INSERT INTO `t_goods` VALUES ('44', '15', '松子', '囤货过冬', '300', '100', '1000', '北京', '', null, '2017-06-06', '2', '/images/goods/15_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('46', '15', '坚果1', '好吃', '450', '234', '1111', null, null, '12', null, '39', '/images/goods/15_1.jpg', '0');
INSERT INTO `t_goods` VALUES ('47', '15', '坚果2', '好吃！！', '300', '233', '0', '北京', null, '12', '2017-06-06', '12', '/images/goods/15_3.jpg', '0');
INSERT INTO `t_goods` VALUES ('48', '15', '坚果3', '非常好吃', '9999', '1000', '0', '北京', null, '12', '2017-06-06', '10', '/images/goods/15_4.jpg', '0');
INSERT INTO `t_goods` VALUES ('49', '22', 'HP笔记本', '8G+128G', '10000', '5000', '1', '', null, null, null, null, null, '0');
INSERT INTO `t_goods` VALUES ('50', '22', 'tt', '44', '44', '44', '44', null, null, null, null, null, null, '0');

-- ----------------------------
-- Table structure for t_goodsdetail
-- ----------------------------
DROP TABLE IF EXISTS `t_goodsdetail`;
CREATE TABLE `t_goodsdetail` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL DEFAULT '0',
  `content` varchar(100) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_goodsdetail
-- ----------------------------

-- ----------------------------
-- Table structure for t_goodsdetailtype
-- ----------------------------
DROP TABLE IF EXISTS `t_goodsdetailtype`;
CREATE TABLE `t_goodsdetailtype` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_goodsdetailtype
-- ----------------------------
INSERT INTO `t_goodsdetailtype` VALUES ('1', '颜色', 'yanse');
INSERT INTO `t_goodsdetailtype` VALUES ('2', '规格', 'guige');
INSERT INTO `t_goodsdetailtype` VALUES ('3', '口味', 'kouwei');
INSERT INTO `t_goodsdetailtype` VALUES ('4', '包装', 'baozhuang');
INSERT INTO `t_goodsdetailtype` VALUES ('5', '尺寸', 'chicun');

-- ----------------------------
-- Table structure for t_order
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_status` int(11) NOT NULL,
  `order_address` varchar(200) NOT NULL,
  `order_postalfee` float NOT NULL,
  `order_date` date NOT NULL,
  `order_postcode` varchar(50) DEFAULT NULL,
  `order_postname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `uid` (`user_id`) USING BTREE,
  CONSTRAINT `t_order_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `t_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='InnoDB free: 6144 kB; (`goods_id`) REFER `mybatis/t_goods`; ';

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('2', '20210201183158875052', '5', '2', '吉林 长春 高新 高新 (赵六收) 15512345678', '11', '2021-02-01', null, null);
INSERT INTO `t_order` VALUES ('8', '20210202192945735021', '5', '2', '吉林 长春 高新 高新 (赵六收) 15512345678', '11', '2021-02-02', null, null);
INSERT INTO `t_order` VALUES ('9', '20210202193255459004', '5', '2', '吉林 长春 高新 高新 (赵六收) 15512345678', '11', '2021-02-02', null, null);
INSERT INTO `t_order` VALUES ('10', '20210202195406365055', '5', '1', '吉林 长春 高新 高新 (赵六收) 15512345678', '12', '2021-02-02', null, null);
INSERT INTO `t_order` VALUES ('11', '20210202202615848048', '5', '2', '吉林 长春 高新 高新 (赵六收) 15512345678', '12', '2021-02-02', null, null);
INSERT INTO `t_order` VALUES ('12', '20210203112548697095', '5', '3', '吉林 长春 高新 高新 (赵六收) 15512345678', '12', '2021-02-03', null, null);
INSERT INTO `t_order` VALUES ('13', '20210205120141475018', '8', '1', '1', '12', '2021-02-05', null, null);
INSERT INTO `t_order` VALUES ('14', '20210205122936457034', '5', '1', '2 2 0 2 (2收) 2', '12', '2021-02-05', null, null);
INSERT INTO `t_order` VALUES ('15', '20210205124343824071', '7', '1', 'a a a a (a收) a', '12', '2021-02-05', null, null);

-- ----------------------------
-- Table structure for t_orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `t_orderdetail`;
CREATE TABLE `t_orderdetail` (
  `odetail_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `goods_id` int(11) DEFAULT NULL,
  `odetail_name` varchar(100) NOT NULL,
  `odetail_price` float NOT NULL,
  `odetail_num` int(11) NOT NULL,
  `odetail_pic` varchar(50) NOT NULL,
  PRIMARY KEY (`odetail_id`),
  KEY `order_id` (`order_id`),
  KEY `t_orderdetail_ibfk_2` (`goods_id`),
  CONSTRAINT `t_orderdetail_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `t_order` (`order_id`),
  CONSTRAINT `t_orderdetail_ibfk_2` FOREIGN KEY (`goods_id`) REFERENCES `t_goods` (`goods_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of t_orderdetail
-- ----------------------------
INSERT INTO `t_orderdetail` VALUES ('2', '2', '4', '女装 军旅式短茄克4', '399', '1', '/images/goods/1_1.jpg');
INSERT INTO `t_orderdetail` VALUES ('3', '2', '5', '女装 军旅式短茄克5', '399', '1', '/images/goods/tj_5.png');
INSERT INTO `t_orderdetail` VALUES ('4', '2', '42', '开口松子', '333', '1', '/images/goods/tj_4.png');
INSERT INTO `t_orderdetail` VALUES ('9', '8', '3', '女装 军旅式短茄克3', '399', '1', '/images/goods/tj_3.png');
INSERT INTO `t_orderdetail` VALUES ('10', '8', '42', '开口松子', '333', '1', '/images/goods/tj_4.png');
INSERT INTO `t_orderdetail` VALUES ('11', '9', '3', '女装 军旅式短茄克3', '399', '1', '/images/goods/tj_3.png');
INSERT INTO `t_orderdetail` VALUES ('12', '9', '42', '开口松子', '333', '1', '/images/goods/tj_4.png');
INSERT INTO `t_orderdetail` VALUES ('13', '10', '48', '坚果3', '9999', '1', '/images/goods/15_4.jpg');
INSERT INTO `t_orderdetail` VALUES ('14', '10', '20', '女装 军旅式短茄克20', '399', '1', '/images/goods/5.png');
INSERT INTO `t_orderdetail` VALUES ('15', '11', '35', '榛子', '350', '2', '/images/goods/tj_2.jpg');
INSERT INTO `t_orderdetail` VALUES ('16', '11', '46', '坚果1', '450', '1', '/images/goods/15_1.jpg');
INSERT INTO `t_orderdetail` VALUES ('17', '12', '1', '女装 军旅式短茄克1', '399', '1', '/images/goods/tj_1.jpg');
INSERT INTO `t_orderdetail` VALUES ('18', '12', '35', '榛子', '350', '1', '/images/goods/tj_2.jpg');
INSERT INTO `t_orderdetail` VALUES ('19', '12', '5', '女装 军旅式短茄克5', '399', '1', '/images/goods/tj_5.png');
INSERT INTO `t_orderdetail` VALUES ('20', '13', '1', '女装 军旅式短茄克1', '399', '3', '/images/goods/tj_1.jpg');
INSERT INTO `t_orderdetail` VALUES ('21', '14', '1', '女装 军旅式短茄克1', '399', '1', '/images/goods/tj_1.jpg');
INSERT INTO `t_orderdetail` VALUES ('22', '15', '5', '女装 军旅式短茄克5', '399', '1', '/images/goods/tj_5.png');

-- ----------------------------
-- Table structure for t_pic
-- ----------------------------
DROP TABLE IF EXISTS `t_pic`;
CREATE TABLE `t_pic` (
  `pic_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `pic_url` varchar(50) NOT NULL,
  PRIMARY KEY (`pic_id`),
  KEY `go_id` (`goods_id`),
  CONSTRAINT `go_id` FOREIGN KEY (`goods_id`) REFERENCES `t_goods` (`goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_pic
-- ----------------------------
INSERT INTO `t_pic` VALUES ('25', '20', '/images/goods/1_1.jpg');
INSERT INTO `t_pic` VALUES ('38', '1', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('39', '1', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('40', '1', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('41', '1', '/images/goods/2_4.jpg');
INSERT INTO `t_pic` VALUES ('42', '1', '/images/goods/2_5.jpg');
INSERT INTO `t_pic` VALUES ('43', '1', '/images/goods/2_6.jpg');
INSERT INTO `t_pic` VALUES ('44', '2', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('45', '3', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('46', '4', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('47', '5', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('48', '6', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('49', '7', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('50', '8', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('51', '9', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('52', '10', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('53', '11', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('54', '12', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('55', '13', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('56', '14', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('57', '15', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('58', '16', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('59', '17', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('60', '18', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('61', '19', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('62', '20', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('63', '21', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('64', '22', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('65', '23', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('66', '24', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('67', '25', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('68', '26', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('69', '27', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('70', '28', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('71', '29', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('72', '31', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('73', '32', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('74', '33', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('75', '34', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('76', '35', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('77', '36', '/images/goods/2_1.jpg');
INSERT INTO `t_pic` VALUES ('78', '36', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('79', '2', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('80', '3', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('81', '4', '/images/goods/2_4.jpg');
INSERT INTO `t_pic` VALUES ('82', '5', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('83', '6', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('84', '7', '/images/goods/2_4.jpg');
INSERT INTO `t_pic` VALUES ('85', '8', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('86', '9', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('87', '10', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('88', '11', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('89', '12', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('90', '13', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('91', '14', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('92', '15', '/images/goods/2_4.jpg');
INSERT INTO `t_pic` VALUES ('93', '16', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('94', '17', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('95', '18', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('96', '19', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('97', '20', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('98', '21', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('99', '22', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('100', '23', '/images/goods/2_4.jpg');
INSERT INTO `t_pic` VALUES ('101', '24', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('102', '25', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('103', '26', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('104', '27', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('105', '28', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('106', '29', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('107', '31', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('108', '32', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('109', '33', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('110', '34', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('111', '35', '/images/goods/2_3.jpg');
INSERT INTO `t_pic` VALUES ('112', '36', '/images/goods/2_4.jpg');
INSERT INTO `t_pic` VALUES ('113', '36', '/images/goods/2_2.jpg');
INSERT INTO `t_pic` VALUES ('114', '42', '/images/goods/pics/14552392714730.jpg');
INSERT INTO `t_pic` VALUES ('115', '42', '/images/goods/pics/14552392714911.jpg');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) DEFAULT NULL,
  `user_pass` varchar(20) DEFAULT NULL,
  `user_age` tinyint(20) DEFAULT NULL,
  `user_sex` tinyint(4) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_rank` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'user', '123', '55', '1', 'eee@126.com', '0');
INSERT INTO `t_user` VALUES ('2', 'jiuqiyuliang', '111', '23', '0', null, '0');
INSERT INTO `t_user` VALUES ('3', 'admin@163.com', '123456', '22', '0', 'admin@163.com', '1');
INSERT INTO `t_user` VALUES ('4', 'admin', '111', '21', '1', null, '1');
INSERT INTO `t_user` VALUES ('5', '11', '11', '11', '1', null, '0');
INSERT INTO `t_user` VALUES ('6', '22', '22', '22', '1', null, '0');
INSERT INTO `t_user` VALUES ('7', '33', '33', '33', '0', null, '0');
INSERT INTO `t_user` VALUES ('8', '44', '44', '44', '1', null, '0');
INSERT INTO `t_user` VALUES ('9', '55', '55', '55', '0', null, '0');
INSERT INTO `t_user` VALUES ('10', '66', '66', '66', '1', null, '0');
INSERT INTO `t_user` VALUES ('11', '77', '77', '77', '1', null, '0');
INSERT INTO `t_user` VALUES ('12', '88', '88', '88', '1', null, '0');
INSERT INTO `t_user` VALUES ('13', '99', '99', '99', '0', null, '0');
INSERT INTO `t_user` VALUES ('14', '00', '00', '0', '0', null, '0');
INSERT INTO `t_user` VALUES ('15', 'aa', 'aa', '11', '1', null, '0');
INSERT INTO `t_user` VALUES ('16', '123', '123', '11', '0', null, '0');
INSERT INTO `t_user` VALUES ('17', '1234', '123', '111', '1', '1@1.1', '0');
INSERT INTO `t_user` VALUES ('18', '12345', '123', '111', '1', '1@1.1', '0');
INSERT INTO `t_user` VALUES ('19', '123456', '123', '111', '1', '1@1.1', '0');
INSERT INTO `t_user` VALUES ('21', 'abc', '123456', '11', '1', '2@2.2', '0');
INSERT INTO `t_user` VALUES ('22', '张三', '123', '11', '1', '1@1.1', '0');
INSERT INTO `t_user` VALUES ('23', '张三1', '123', '11', '1', '1@1.1', '0');
INSERT INTO `t_user` VALUES ('24', '张三2', '123', '11', '1', '1@1.1', '0');
INSERT INTO `t_user` VALUES ('26', 'aaa', 'aaa', '11', '1', null, '0');
INSERT INTO `t_user` VALUES ('27', 'bbb', 'bbb', '11', '1', null, '0');
INSERT INTO `t_user` VALUES ('29', 'ccc', 'ccc', '11', '1', null, '0');
INSERT INTO `t_user` VALUES ('30', 'ddd', '1', '55', '1', null, '0');
INSERT INTO `t_user` VALUES ('31', 'aa55', '11', '11', '1', '11', '0');
INSERT INTO `t_user` VALUES ('32', 'qq', 'qq', '11', '1', 'qq', null);
INSERT INTO `t_user` VALUES ('34', 'qqssfsfs', 'qq', '11', '1', 'qq', null);
INSERT INTO `t_user` VALUES ('35', 'zhang', '12345', '12', '1', 'd', null);
INSERT INTO `t_user` VALUES ('36', 'dffasfasd', 'fdfsf', '2', '0', '2222', null);
INSERT INTO `t_user` VALUES ('38', 'zhangsanh', null, null, null, null, null);
